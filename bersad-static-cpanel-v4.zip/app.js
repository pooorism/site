
(async function(){
  const $ = (s)=>document.querySelector(s);
  const $$ = (s)=>Array.from(document.querySelectorAll(s));

  const state = { products:[], filtered:[], site:null };

  function setTheme(theme){
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("bersad_theme", theme);
  }
  function toggleTheme(){
    const cur = document.documentElement.getAttribute("data-theme") || "dark";
    setTheme(cur === "dark" ? "light" : "dark");
  }

  async function loadJSON(url){
    const res = await fetch(url, {cache:"no-store"});
    if(!res.ok) throw new Error("Fetch failed: " + url + " " + res.status);
    return res.json();
  }

  function fmtPrice(n){
    if(!n || Number(n) <= 0) return "تماس بگیرید";
    try { return new Intl.NumberFormat("fa-IR").format(Number(n)) + " تومان"; }
    catch { return n + " تومان"; }
  }

  function applySiteVars(site){
    const root = document.documentElement;
    root.style.setProperty("--site-bg", `url('${site.site_bg}')`);
    root.style.setProperty("--hero-bg", `url('${site.hero_bg}')`);
    root.style.setProperty("--catalog-bg", `url('${site.catalog_bg}')`);
    root.style.setProperty("--watermark", `url('${site.watermark_svg}')`);
    const logo = $("#logoImg"); if(logo) logo.src = site.logo;
    const hero = $("#heroImg"); if(hero) hero.src = site.hero_bg;
  }

  function buildBrandOptions(){
    const sel = $("#brand");
    const brands = Array.from(new Set(state.products.map(p=>p.brand))).sort((a,b)=>a.localeCompare(b));
    brands.forEach(b=>{
      const opt = document.createElement("option");
      opt.value = b; opt.textContent = b;
      sel.appendChild(opt);
    });
  }

  function cardTpl(p){
    const img = p.image || "assets/product-placeholder.svg";
    return `
      <article class="card" data-id="${p.id}">
        <div class="card__img">
          <img src="${img}" alt="${escapeHtml(p.name)}" loading="lazy" />
        </div>
        <div class="card__body">
          <h3 class="card__name">${escapeHtml(p.name)}</h3>
          <div class="card__meta">
            <span>${escapeHtml(p.brand)}</span>
            <span>${escapeHtml(p.sku)}</span>
          </div>
          <div class="card__price">${fmtPrice(p.price)}</div>
        </div>
      </article>
    `;
  }

  function escapeHtml(str){
    return String(str ?? "").replace(/[&<>"']/g, (m)=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[m]));
  }

  function render(){
    const grid = $("#grid");
    const empty = $("#empty");
    grid.innerHTML = state.filtered.map(cardTpl).join("");
    empty.classList.toggle("hidden", state.filtered.length !== 0);
    $$(".card").forEach(el=>{
      el.addEventListener("click", ()=>openModal(el.getAttribute("data-id")));
    });
  }

  function filter(){
    const q = ($("#q").value || "").trim().toLowerCase();
    const b = $("#brand").value || "";
    state.filtered = state.products.filter(p=>{
      const hitQ = !q || (p.name||"").toLowerCase().includes(q) || (p.brand||"").toLowerCase().includes(q) || (p.sku||"").toLowerCase().includes(q);
      const hitB = !b || p.brand === b;
      return hitQ && hitB;
    });
    render();
  }

  function openModal(id){
    const p = state.products.find(x=>x.id===id);
    if(!p) return;
    $("#mImg").src = p.image || "assets/product-placeholder.svg";
    $("#mImg").alt = p.name || "";
    $("#mBrand").textContent = p.brand || "";
    $("#mTitle").textContent = p.name || "";
    $("#mSku").textContent = p.sku || "";
    $("#mPrice").textContent = fmtPrice(p.price);
    $("#mDesc").textContent = p.description || "";
    const msg = encodeURIComponent(`سلام، برای ${p.name} با کد ${p.sku} موجودی و قیمت رو می‌خواستم.`);
    $("#mWa").href = `https://wa.me/989122135489?text=${msg}`;
    $("#modal").classList.remove("hidden");
    document.body.style.overflow="hidden";
  }
  function closeModal(){
    $("#modal").classList.add("hidden");
    document.body.style.overflow="";
  }

  function wire(){
    $("#themeBtn").addEventListener("click", toggleTheme);
    $("#q").addEventListener("input", filter);
    $("#brand").addEventListener("change", filter);
    $("#modalClose").addEventListener("click", closeModal);
    $("#modalX").addEventListener("click", closeModal);
    document.addEventListener("keydown", (e)=>{ if(e.key==="Escape") closeModal(); });

    $("#waBtn").addEventListener("click", ()=>{
      window.open("https://wa.me/989122135489?text=%D8%B3%D9%84%D8%A7%D9%85%D8%8C%20%D9%85%DB%8C%E2%80%8C%D8%AE%D9%88%D8%A7%D8%B3%D8%AA%D9%85%20%D8%AF%D8%B1%D8%A8%D8%A7%D8%B1%D9%87%20%D9%85%D8%AD%D8%B5%D9%88%D9%84%D8%A7%D8%AA%20%D8%A7%D8%B7%D9%84%D8%A7%D8%B9%D8%A7%D8%AA%20%D8%A8%DA%AF%DB%8C%D8%B1%D9%85.", "_blank", "noopener");
    });

    const nav = $("#nav");
    $("#menuBtn").addEventListener("click", ()=>{
      nav.classList.toggle("hidden");
    });
    // close nav on click
    $$(".nav__link").forEach(a=>{
      a.addEventListener("click", ()=>nav.classList.add("hidden"));
    });

    // default nav hidden on small screens
    if(window.matchMedia("(max-width: 720px)").matches){
      nav.classList.add("hidden");
    }
  }

  async function init(){
    try{
      state.site = await loadJSON("data/site.json");
      applySiteVars(state.site);

      const saved = localStorage.getItem("bersad_theme") || state.site.theme_default || "dark";
      setTheme(saved);

      const data = await loadJSON("data/products.json");
      state.products = (data.products || []).map(p=>({
        id: String(p.id||""),
        name: p.name||"",
        brand: p.brand||"",
        sku: p.sku||"",
        price: Number(p.price||0),
        image: p.image||"assets/product-placeholder.svg",
        description: p.description||""
      }));
      state.filtered = state.products.slice();

      buildBrandOptions();
      wire();
      render();
    }catch(err){
      console.error(err);
      const grid = $("#grid");
      grid.innerHTML = `<div class="empty">خطا در بارگذاری داده‌ها. لطفاً دسترسی فایل‌ها و مسیرها را بررسی کنید.</div>`;
    }
  }

  await init();
})();
