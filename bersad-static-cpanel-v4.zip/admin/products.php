<?php require_once __DIR__ . '/config.php'; require_login();
$data = read_json(PRODUCTS_FILE);
$products = $data['products'] ?? [];
?><!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>مدیریت محصولات | برساد</title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;800&display=swap" rel="stylesheet">
<style>
body{margin:0;font-family:Vazirmatn,system-ui;background:#0b0710;color:#fff}
.top{display:flex;gap:10px;justify-content:space-between;align-items:center;padding:14px 16px;border-bottom:1px solid rgba(242,194,90,.18);position:sticky;top:0;background:rgba(11,7,16,.9);backdrop-filter:blur(10px)}
a{color:#f2c25a;text-decoration:none;font-weight:800}
.btn{padding:10px 14px;border-radius:999px;background:linear-gradient(135deg,#f2c25a,#c9962d);color:#1a0d22;font-weight:900;border:0;cursor:pointer}
.btn2{padding:10px 14px;border-radius:999px;background:transparent;color:#fff;font-weight:900;border:1px solid rgba(242,194,90,.18)}
.container{max-width:1100px;margin:0 auto;padding:14px 16px}
.table{width:100%;border-collapse:separate;border-spacing:0 10px}
tr{background:rgba(255,255,255,.06);border:1px solid rgba(242,194,90,.18)}
td,th{padding:10px 12px}
th{color:rgba(255,255,255,.75);text-align:right;font-weight:800}
.row{border-radius:16px}
.actions a{margin-left:10px}
img{width:52px;height:52px;object-fit:cover;border-radius:12px;border:1px solid rgba(242,194,90,.18);background:rgba(0,0,0,.2)}
.small{color:rgba(255,255,255,.65);font-size:13px}
@media(max-width:720px){
  .hide-m{display:none}
}
</style>
</head>
<body>
  <div class="top">
    <div>
      <strong>پنل مدیریت</strong>
      <div class="small">فقط مدیریت محصولات و تصاویر سایت</div>
    </div>
    <div style="display:flex;gap:10px;align-items:center">
      <a class="btn2" href="site.php">تصاویر و تنظیمات سایت</a>
      <a class="btn" href="product_edit.php">افزودن محصول</a>
      <a class="btn2" href="logout.php">خروج</a>
    </div>
  </div>

  <div class="container">
    <table class="table">
      <thead>
        <tr>
          <th>تصویر</th>
          <th>نام</th>
          <th class="hide-m">برند</th>
          <th class="hide-m">کد</th>
          <th>قیمت</th>
          <th>عملیات</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach($products as $p): 
        $img = $p['image'] ?? '';
      ?>
        <tr class="row">
          <td><?php if($img): ?><img src="<?php echo htmlspecialchars('../'.$img); ?>" alt=""/><?php else: ?>—<?php endif; ?></td>
          <td><?php echo htmlspecialchars($p['name'] ?? ''); ?></td>
          <td class="hide-m"><?php echo htmlspecialchars($p['brand'] ?? ''); ?></td>
          <td class="hide-m"><?php echo htmlspecialchars($p['sku'] ?? ''); ?></td>
          <td><?php echo htmlspecialchars((string)($p['price'] ?? 0)); ?></td>
          <td class="actions">
            <a href="product_edit.php?id=<?php echo urlencode($p['id']); ?>">ویرایش</a>
            <a href="product_delete.php?id=<?php echo urlencode($p['id']); ?>" onclick="return confirm('حذف شود؟')">حذف</a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
