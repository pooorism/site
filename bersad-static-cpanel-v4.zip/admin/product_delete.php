<?php require_once __DIR__ . '/config.php'; require_login();
$id = $_GET['id'] ?? '';
$data = read_json(PRODUCTS_FILE);
$products = $data['products'] ?? [];
$products2 = [];
foreach($products as $p){
  if(($p['id'] ?? '') === $id){
    // optionally delete uploaded file
    $img = $p['image'] ?? '';
    if(strpos($img, 'admin/uploads/products/') === 0){
      $path = dirname(__DIR__) . '/' . $img;
      if(file_exists($path)) @unlink($path);
    }
    continue;
  }
  $products2[] = $p;
}
write_json(PRODUCTS_FILE, ['products'=>$products2]);
header('Location: products.php'); exit;
