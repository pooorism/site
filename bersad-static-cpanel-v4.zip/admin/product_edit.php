<?php require_once __DIR__ . '/config.php'; require_login();
$data = read_json(PRODUCTS_FILE);
$products = $data['products'] ?? [];

$id = $_GET['id'] ?? '';
$current = null;
foreach($products as $p){ if(($p['id'] ?? '') === $id){ $current = $p; break; } }

function make_id(){
  return 'p' . str_pad((string)rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

$err = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $pid = trim($_POST['id'] ?? '');
  $name = trim($_POST['name'] ?? '');
  $brand = trim($_POST['brand'] ?? '');
  $sku = trim($_POST['sku'] ?? '');
  $price = (int)($_POST['price'] ?? 0);
  $desc = trim($_POST['description'] ?? '');

  if($pid === '') $pid = make_id();
  if($name === '' || $brand === '' || $sku === ''){
    $err = 'نام، برند و کد محصول الزامی است.';
  }else{
    $imgPath = $current['image'] ?? 'assets/product-placeholder.svg';

    if(isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK){
      $tmp = $_FILES['image']['tmp_name'];
      $orig = $_FILES['image']['name'];
      $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
      if(!in_array($ext, ['jpg','jpeg','png','webp','gif','svg'])){
        $err = 'فرمت تصویر مجاز نیست.';
      }else{
        if(!is_dir(UPLOAD_PRODUCTS)) @mkdir(UPLOAD_PRODUCTS, 0755, true);
        $fname = safe_name($pid . '-' . time() . '.' . $ext);
        $dest = UPLOAD_PRODUCTS . '/' . $fname;
        if(move_uploaded_file($tmp, $dest)){
          $imgPath = 'admin/uploads/products/' . $fname;
        }else{
          $err = 'آپلود تصویر ناموفق بود.';
        }
      }
    }

    if($err === ''){
      $found = false;
      for($i=0;$i<count($products);$i++){
        if(($products[$i]['id'] ?? '') === $pid){
          $products[$i] = [
            'id'=>$pid,'name'=>$name,'brand'=>$brand,'sku'=>$sku,'price'=>$price,
            'image'=>$imgPath,'description'=>$desc
          ];
          $found = true; break;
        }
      }
      if(!$found){
        $products[] = [
          'id'=>$pid,'name'=>$name,'brand'=>$brand,'sku'=>$sku,'price'=>$price,
          'image'=>$imgPath,'description'=>$desc
        ];
      }
      write_json(PRODUCTS_FILE, ['products'=>$products]);
      header('Location: products.php'); exit;
    }
  }
}

?><!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>ویرایش محصول | برساد</title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;800&display=swap" rel="stylesheet">
<style>
body{margin:0;font-family:Vazirmatn,system-ui;background:#0b0710;color:#fff}
.top{display:flex;gap:10px;justify-content:space-between;align-items:center;padding:14px 16px;border-bottom:1px solid rgba(242,194,90,.18);position:sticky;top:0;background:rgba(11,7,16,.9);backdrop-filter:blur(10px)}
a{color:#f2c25a;text-decoration:none;font-weight:800}
.container{max-width:760px;margin:0 auto;padding:14px 16px}
.card{background:rgba(255,255,255,.06);border:1px solid rgba(242,194,90,.18);border-radius:18px;padding:16px}
label{display:block;margin:10px 0 6px;color:rgba(255,255,255,.78);font-weight:800}
input,textarea{width:100%;padding:12px;border-radius:14px;border:1px solid rgba(242,194,90,.18);background:rgba(0,0,0,.25);color:#fff;font-weight:700}
textarea{min-height:110px;line-height:1.9}
.row{display:grid;gap:12px}
@media(min-width:720px){.row{grid-template-columns:1fr 1fr}}
.btn{margin-top:12px;width:100%;padding:12px;border:0;border-radius:999px;background:linear-gradient(135deg,#f2c25a,#c9962d);color:#1a0d22;font-weight:900;cursor:pointer}
.err{margin-top:10px;color:#ffb3b3;font-weight:800}
.small{color:rgba(255,255,255,.65);font-size:13px}
img{width:88px;height:88px;object-fit:cover;border-radius:14px;border:1px solid rgba(242,194,90,.18);background:rgba(0,0,0,.2)}
</style>
</head>
<body>
  <div class="top">
    <strong><?php echo $id ? 'ویرایش محصول' : 'افزودن محصول'; ?></strong>
    <a href="products.php">بازگشت</a>
  </div>
  <div class="container">
    <div class="card">
      <form method="post" enctype="multipart/form-data">
        <div class="row">
          <div>
            <label>شناسه (id)</label>
            <input name="id" value="<?php echo htmlspecialchars($current['id'] ?? ''); ?>" placeholder="اگر خالی باشد خودکار ساخته می‌شود" />
          </div>
          <div>
            <label>کد محصول (SKU)</label>
            <input name="sku" required value="<?php echo htmlspecialchars($current['sku'] ?? ''); ?>" />
          </div>
        </div>

        <label>نام محصول</label>
        <input name="name" required value="<?php echo htmlspecialchars($current['name'] ?? ''); ?>" />

        <div class="row">
          <div>
            <label>برند</label>
            <input name="brand" required value="<?php echo htmlspecialchars($current['brand'] ?? ''); ?>" />
          </div>
          <div>
            <label>قیمت</label>
            <input name="price" type="number" value="<?php echo htmlspecialchars((string)($current['price'] ?? 0)); ?>" />
            <div class="small">اگر صفر باشد در سایت «تماس بگیرید» نمایش داده می‌شود.</div>
          </div>
        </div>

        <label>توضیحات</label>
        <textarea name="description"><?php echo htmlspecialchars($current['description'] ?? ''); ?></textarea>

        <label>تصویر محصول (اختیاری)</label>
        <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp,.gif,.svg" />
        <div class="small">
          تصویر فعلی:
          <?php if(!empty($current['image'])): ?>
            <img src="<?php echo htmlspecialchars('../'.$current['image']); ?>" alt=""/>
          <?php else: ?>
            ندارد
          <?php endif; ?>
        </div>

        <button class="btn" type="submit">ذخیره</button>
        <?php if($err): ?><div class="err"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>
      </form>
    </div>
  </div>
</body>
</html>
