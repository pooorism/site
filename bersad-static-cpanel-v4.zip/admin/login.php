<?php require_once __DIR__ . '/config.php';
if(is_logged_in()){ header('Location: products.php'); exit; }
$error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $u = trim($_POST['username'] ?? '');
  $p = trim($_POST['password'] ?? '');
  if($u === ADMIN_USER && $p === ADMIN_PASS){
    $_SESSION['admin'] = true;
    header('Location: products.php');
    exit;
  }else{
    $error = 'نام کاربری یا رمز عبور اشتباه است.';
  }
}
?><!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>ورود مدیر | برساد</title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;800&display=swap" rel="stylesheet">
<style>
body{margin:0;font-family:Vazirmatn,system-ui;background:#0b0710;color:#fff;display:grid;place-items:center;min-height:100vh}
.card{width:min(420px,calc(100% - 24px));background:rgba(255,255,255,.06);border:1px solid rgba(242,194,90,.22);border-radius:18px;padding:18px}
h1{margin:0 0 12px;font-size:18px}
label{display:block;margin:10px 0 6px;color:rgba(255,255,255,.78);font-weight:700}
input{width:100%;padding:12px;border-radius:14px;border:1px solid rgba(242,194,90,.18);background:rgba(0,0,0,.25);color:#fff;font-weight:700}
.btn{margin-top:12px;width:100%;padding:12px;border:0;border-radius:999px;background:linear-gradient(135deg,#f2c25a,#c9962d);color:#1a0d22;font-weight:900;cursor:pointer}
.err{margin-top:10px;color:#ffb3b3;font-weight:700}
a{color:#f2c25a;text-decoration:none;font-weight:800}
.small{margin-top:12px;color:rgba(255,255,255,.65);font-size:13px}
</style>
</head>
<body>
  <div class="card">
    <h1>ورود مدیر</h1>
    <form method="post" autocomplete="off">
      <label>نام کاربری</label>
      <input name="username" required />
      <label>رمز عبور</label>
      <input name="password" type="password" required />
      <button class="btn" type="submit">ورود</button>
      <?php if($error): ?><div class="err"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    </form>
    <div class="small"><a href="../index.html">بازگشت به سایت</a></div>
  </div>
</body>
</html>
