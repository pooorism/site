<?php require_once __DIR__ . '/config.php'; require_login();
$site = read_json(SITE_FILE);
$err = '';
$ok = '';

function handle_upload($field, $key){
  global $site, $err;
  if(!isset($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return;
  $tmp = $_FILES[$field]['tmp_name'];
  $orig = $_FILES[$field]['name'];
  $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
  if(!in_array($ext, ['jpg','jpeg','png','webp','svg','gif'])){
    $err = 'فرمت فایل برای '.$field.' مجاز نیست.';
    return;
  }
  if(!is_dir(UPLOAD_SITE)) @mkdir(UPLOAD_SITE, 0755, true);
  $fname = safe_name($key . '-' . time() . '.' . $ext);
  $dest = UPLOAD_SITE . '/' . $fname;
  if(move_uploaded_file($tmp, $dest)){
    $site[$key] = 'admin/uploads/site/' . $fname;
  }else{
    $err = 'آپلود فایل ناموفق بود.';
  }
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $site['theme_default'] = ($_POST['theme_default'] ?? 'dark') === 'light' ? 'light' : 'dark';

  handle_upload('hero_bg','hero_bg');
  handle_upload('site_bg','site_bg');
  handle_upload('catalog_bg','catalog_bg');
  handle_upload('watermark_svg','watermark_svg');
  handle_upload('logo','logo');

  if($err === ''){
    write_json(SITE_FILE, $site);
    $ok = 'ذخیره شد. برای مشاهده تغییرات، صفحه سایت را رفرش کنید.';
  }
}

?><!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>تنظیمات سایت | برساد</title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;800&display=swap" rel="stylesheet">
<style>
body{margin:0;font-family:Vazirmatn,system-ui;background:#0b0710;color:#fff}
.top{display:flex;gap:10px;justify-content:space-between;align-items:center;padding:14px 16px;border-bottom:1px solid rgba(242,194,90,.18);position:sticky;top:0;background:rgba(11,7,16,.9);backdrop-filter:blur(10px)}
a{color:#f2c25a;text-decoration:none;font-weight:800}
.container{max-width:820px;margin:0 auto;padding:14px 16px}
.card{background:rgba(255,255,255,.06);border:1px solid rgba(242,194,90,.18);border-radius:18px;padding:16px}
label{display:block;margin:10px 0 6px;color:rgba(255,255,255,.78);font-weight:800}
input,select{width:100%;padding:12px;border-radius:14px;border:1px solid rgba(242,194,90,.18);background:rgba(0,0,0,.25);color:#fff;font-weight:700}
.btn{margin-top:12px;width:100%;padding:12px;border:0;border-radius:999px;background:linear-gradient(135deg,#f2c25a,#c9962d);color:#1a0d22;font-weight:900;cursor:pointer}
.msg{margin-top:10px;font-weight:800}
.ok{color:#b8ffd2}
.err{color:#ffb3b3}
.small{color:rgba(255,255,255,.65);font-size:13px;line-height:1.8}
img{max-width:100%;border-radius:14px;border:1px solid rgba(242,194,90,.18);background:rgba(0,0,0,.2)}
.grid{display:grid;gap:12px}
@media(min-width:780px){.grid{grid-template-columns:1fr 1fr}}
</style>
</head>
<body>
  <div class="top">
    <strong>تصاویر و تنظیمات سایت</strong>
    <a href="products.php">بازگشت</a>
  </div>
  <div class="container">
    <div class="card">
      <form method="post" enctype="multipart/form-data">
        <label>حالت پیش‌فرض</label>
        <select name="theme_default">
          <option value="dark" <?php echo ($site['theme_default'] ?? 'dark')==='dark'?'selected':''; ?>>تاریک</option>
          <option value="light" <?php echo ($site['theme_default'] ?? 'dark')==='light'?'selected':''; ?>>روشن</option>
        </select>
        <div class="small">کاربر می‌تواند در هدر حالت روشن/تاریک را تغییر دهد.</div>

        <div class="grid">
          <div>
            <label>لوگو</label>
            <input type="file" name="logo" accept=".png,.webp,.svg,.jpg,.jpeg" />
            <div class="small">فعلی:</div>
            <img src="<?php echo htmlspecialchars('../'.($site['logo'] ?? '')); ?>" alt=""/>
          </div>
          <div>
            <label>پس‌زمینه هیرو</label>
            <input type="file" name="hero_bg" accept=".png,.webp,.jpg,.jpeg" />
            <div class="small">فعلی:</div>
            <img src="<?php echo htmlspecialchars('../'.($site['hero_bg'] ?? '')); ?>" alt=""/>
          </div>
          <div>
            <label>پس‌زمینه کلی سایت</label>
            <input type="file" name="site_bg" accept=".png,.webp,.jpg,.jpeg" />
            <div class="small">فعلی:</div>
            <img src="<?php echo htmlspecialchars('../'.($site['site_bg'] ?? '')); ?>" alt=""/>
          </div>
          <div>
            <label>پس‌زمینه بخش کاتالوگ</label>
            <input type="file" name="catalog_bg" accept=".png,.webp,.jpg,.jpeg" />
            <div class="small">فعلی:</div>
            <img src="<?php echo htmlspecialchars('../'.($site['catalog_bg'] ?? '')); ?>" alt=""/>
          </div>
          <div>
            <label>واترمارک وکتور عطر (SVG)</label>
            <input type="file" name="watermark_svg" accept=".svg,.png,.webp" />
            <div class="small">فعلی:</div>
            <img src="<?php echo htmlspecialchars('../'.($site['watermark_svg'] ?? '')); ?>" alt=""/>
          </div>
        </div>

        <button class="btn" type="submit">ذخیره</button>
        <?php if($ok): ?><div class="msg ok"><?php echo htmlspecialchars($ok); ?></div><?php endif; ?>
        <?php if($err): ?><div class="msg err"><?php echo htmlspecialchars($err); ?></div><?php endif; ?>
      </form>
    </div>
  </div>
</body>
</html>
