<?php
// تنظیمات ورود مدیر
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'Bersad@1403'); // بعد از نصب روی هاست تغییر بده

define('DATA_DIR', dirname(__DIR__) . '/data');
define('PRODUCTS_FILE', DATA_DIR . '/products.json');
define('SITE_FILE', DATA_DIR . '/site.json');

define('UPLOAD_PRODUCTS', __DIR__ . '/uploads/products');
define('UPLOAD_SITE', __DIR__ . '/uploads/site');

session_start();
function is_logged_in(){ return isset($_SESSION['admin']) && $_SESSION['admin'] === true; }
function require_login(){
  if(!is_logged_in()){
    header('Location: login.php');
    exit;
  }
}
function read_json($path){
  if(!file_exists($path)) return [];
  $raw = file_get_contents($path);
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}
function write_json($path, $data){
  $raw = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
  file_put_contents($path, $raw, LOCK_EX);
}
function safe_name($s){
  $s = preg_replace('/[^a-zA-Z0-9._-]+/', '-', $s);
  return trim($s, '-');
}
?>
